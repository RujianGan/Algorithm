package com.jimmysun.algorithms.chapter1_1;

public class Ex08 {
	public static void main(String[] args) {
		System.out.println('b');
		System.out.println('b' + 'c');
		System.out.println((char) ('a' + 4));
	}
}
