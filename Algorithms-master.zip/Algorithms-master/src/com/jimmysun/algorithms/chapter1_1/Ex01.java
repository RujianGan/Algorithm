package com.jimmysun.algorithms.chapter1_1;

public class Ex01 {
	public static void main(String[] args) {
		System.out.println((0 + 15) / 2);
		System.out.println(2.0e-6 * 100000000.1);
		System.out.println(true && false || true && true);
	}
}
