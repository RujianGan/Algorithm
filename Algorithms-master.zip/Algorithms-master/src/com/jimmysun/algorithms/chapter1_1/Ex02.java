package com.jimmysun.algorithms.chapter1_1;

public class Ex02 {
	public static void main(String[] args) {
		System.out.println((1 + 2.236) / 2);
		System.out.println(1 + 2 + 3 + 4.0);
		System.out.println(4.1 >= 4);
		System.out.println(1 + 2 + "3");
	}
}
